from django.apps import AppConfig


class ChartjsConfig(AppConfig):
    name = 'chartjs'
